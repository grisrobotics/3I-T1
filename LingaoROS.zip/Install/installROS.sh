#!/usr/bin/env bash

set -e

code_name=$(lsb_release -sc)

if [ "$code_name" = "bionic" ]; then
    ros_version="melodic"
elif [ "$code_name" = "xenial" ]; then
    ros_version="kinetic"
else
    echo " LingAo ROS Install not support "$code_name
    exit
fi 

LOCAL_IP=`ip addr | grep 'state UP' -A2 | tail -n1 | awk '{print $2}' | awk -F"/" '{print $1}'`
if [ ! ${LOCAL_IP} ]; then
    echo "please check network"
    exit
fi

echo "请选择你的小车类型,默认LA_4WD_LingFeng"
echo "please specify LingAo model(0:LA_2WD,1:LA_4WD,2:LA_4WD_LingFeng,3:LA_MECANUM,other for user defined):"
read -p "(Default: LA_4WD_LingFeng):" LINGAO_BASE_INPUT
if [ -z $LINGAO_BASE_INPUT ]; then
        LINGAO_BASE_INPUT="2"
fi

if [ "$LINGAO_BASE_INPUT" = "0" ]; then
    LINGAO_BASE='LA_2WD'
elif [ "$LINGAO_BASE_INPUT" = "1" ]; then
    LINGAO_BASE='LA_4WD'
elif [ "$LINGAO_BASE_INPUT" = "2" ]; then
    LINGAO_BASE='LA_4WD_LingFeng'
elif [ "$LINGAO_BASE_INPUT" = "3" ]; then
    LINGAO_BASE='LA_MECANUM'
else
    LINGAO_BASE=$LINGAO_BASE_INPUT 
fi

echo ""
echo "请选择你使用的雷达,默认rplidar"
echo "please specify your lidar(0:rplidar,1:rplidar_a3,2:ydlidar,other for user defined):"
read -p "(Default: rplidar):" LINGAO_LIDAR_INPUT
if [ -z $LINGAO_LIDAR_INPUT ]; then
        LINGAO_LIDAR_INPUT="0"
fi

if [ "$LINGAO_LIDAR_INPUT" = "0" ]; then
    LINGAO_LIDAR='rplidar'
elif [ "$LINGAO_LIDAR_INPUT" = "1" ]; then
    LINGAO_LIDAR='rplidar_a3'
elif [ "$LINGAO_LIDAR_INPUT" = "2" ]; then
    LINGAO_LIDAR='ydlidar'
else
    LINGAO_LIDAR=$LINGAO_LIDAR_INPUT
	echo "Please install the radar driver yourself"
	printf "请自己安装雷达驱动"
fi

echo ""
echo "请选择ROS_MASTA运行的设备(当前设备ip:$LOCAL_IP); 0:当前设备(默认); 1:其他设备"
echo "please select the onboard machine running ROS_MASTER, current machine(ip:$LOCAL_IP) type(0:onboard,other:remote):"
read -p "(Default: onboard):" LINGAO_MACHINE_VALUE

if [ -z $LINGAO_MACHINE_VALUE ]; then
        LINGAO_MACHINE_VALUE="0"
fi

if [ "$LINGAO_MACHINE_VALUE" = "0" ]; then
    ROS_MASTER_IP_STR="\`hostname -I | awk '{print \$1}'\`"
    ROS_MASTER_IP=`echo $LOCAL_IP`
else
	echo "请输入ROS_MASTA运行的IP地址"
    read -p "plase specify the onboard machine ip for commnicationi:" LINGAO_ONBOARD_MACHINE_IP
    ROS_MASTER_IP_STR=`echo $LINGAO_ONBOARD_MACHINE_IP`
    ROS_MASTER_IP=`echo $LINGAO_ONBOARD_MACHINE_IP`
fi

echo ""
echo "*****************************************************************"
echo "model: " $LINGAO_BASE 
echo "lidar: " $LINGAO_LIDAR  
echo "local_ip: " ${LOCAL_IP} 
echo "ROS_MASTER_IP:" ${ROS_MASTER_IP}
echo ""
echo "确定要安装灵遨 ROS-$ros_version 组件包吗，确认安装请输入[y]继续"
echo "Are you sure install LingAo ROS Packages?  "
echo "*****************************************************************"
read -p "Enter [y] to continue :" reply
        if [[ "$reply" != "y" && "$reply" != "Y" ]]
            then
                echo "Wrong input. Exiting now"
                exit 1
        fi

echo
echo "INSTALLING NOW...."
echo

source /opt/ros/${ros_version}/setup.bash


sudo apt-get update
sudo apt-get install -y \
git \
avahi-daemon \
openssh-server \
python-setuptools \
python-dev \
build-essential \
chrony \
libgeographic-dev

cd $HOME
mkdir -p lingao_ws/src
cd $HOME/lingao_ws/src
set +e
catkin_init_workspace

if [ $ros_version == "melodic" ]
    then
        git clone https://github.com/ros-perception/openslam_gmapping.git
        git clone https://github.com/ros-perception/slam_gmapping.git

else
    sudo apt-get install -y \
    python-gudev \
    ros-$ros_version-gmapping \
    ros-$ros_version-map-server
fi
set -e

cd $HOME/lingao_ws/
catkin_make
source devel/setup.bash

echo
echo "INSTALLING ROS Packges ING...."
echo

# ros-$ros_version-rosserial-arduino 

sudo apt-get install -y \
ros-$ros_version-roslint \
ros-$ros_version-rosserial \
ros-$ros_version-imu-filter-madgwick \
ros-$ros_version-navigation \
ros-$ros_version-robot-localization \
ros-$ros_version-imu-filter-madgwick  \
ros-$ros_version-robot-pose-ekf \
ros-$ros_version-tf2 \
ros-$ros_version-tf2-ros 

echo
echo "INSTALLING LIDAR ING...."
echo

set +e
if [ "$LINGAO_LIDAR" == "rplidar" ] || [ "$LINGAO_LIDAR" == "rplidar_a3" ]
		then
			cd $HOME/lingao_ws/src
			git clone https://github.com/robopeak/rplidar_ros.git
			echo "start copy rplidar.rules to  /etc/udev/rules.d/"
			sudo cp rules/rplidar.rules  /etc/udev/rules.d
elif [ "$LINGAO_LIDAR" == "ydlidar" ]
        then
            cd $HOME/lingao_ws/src
            git clone https://github.com/EAIBOT/ydlidar.git
			echo "start copy ydlidar.rules to  /etc/udev/rules.d/"
			sudo cp rules/ydlidar.rules  /etc/udev/rules.d
fi
set -e

cd $HOME/lingao_ws/
catkin_make

echo "start copy lingao.rules to  /etc/udev/rules.d/"
sudo sudo cp rules/lingao.rules  /etc/udev/rules.d

echo " "
echo "Restarting udev"
echo ""
sudo service udev reload
#sudo service udev restart


echo "source ~/lingao_ws/devel/setup.bash" >> $HOME/.bashrc

echo "export ROS_IP=\`hostname -I | awk '{print \$1}'\`" >> ~/.bashrc
echo "export ROS_HOSTNAME=\`hostname -I | awk '{print \$1}'\`" >> ~/.bashrc
echo "export ROS_MASTER_URI=http://\`hostname -I | awk '{print \$1}'\`:11311" >> ~/.bashrc

echo "export LINGAOLIDAR=$LINGAO_LIDAR" >> $HOME/.bashrc
echo "export LINGAOBASE=$LINGAO_BASE" >> $HOME/.bashrc


source ~/.bashrc

echo
echo "INSTALLATION DONE!"
echo






