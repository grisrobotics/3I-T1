#include "lingao_base.h"

int main(int argc, char** argv )
{
    ros::init(argc, argv, "lingao_base_node");
    LINGAOBASE lino;
    ros::spin();
    return 0;
}